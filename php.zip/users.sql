-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2023 at 04:23 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `village_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `middleName` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `familyName` varchar(255) NOT NULL,
  `village` varchar(255) DEFAULT NULL,
  `fatherName` varchar(255) DEFAULT NULL,
  `motherName` varchar(255) DEFAULT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `residentAddress` varchar(255) DEFAULT NULL,
  `ageGrade` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstName`, `lastName`, `middleName`, `title`, `familyName`, `village`, `fatherName`, `motherName`, `phoneNumber`, `email`, `occupation`, `residentAddress`, `ageGrade`, `password`) VALUES
(1, 'Henrichy', 'Nzekwe', 'henrt@gmail.com', 'ggff', 'ggg', 'Ogbaku', 'ggg', 'hhhh', '08033449665', 'henrynzekwe25@gmail.com', 'web developer', 'Ikorodu', '55', '$2y$10$Wq5R0kAd270OqIa9qHcThuYh83N5Z8L/FWVZJRu15DwhxkpaTz3lS'),
(3, 'Henry', 'Nzekwe', 'hhhh', 'ggff', 'ggg', 'Ogbaku', 'ggg', 'hhhh', '+2347064761607', 'henrykwe25@gmail.com', 'web developer', 'Ikorodu', '55', '$2y$10$e27Cj3.fp.mPyR.PpRCoeegeyGsP2QarEa06ejFXwdZDkvpX.LS22'),
(5, 'Henry', 'Nzekwe', 'hhhh', 'ggff', 'ggg', 'Ogbaku', 'ggg', 'hhhh', '+2347064761609', 'henrykwel25@gmail.com', 'web developer', 'Ikorodu', '55', '$2y$10$WU81/2ZrUrKi82JHCXNED.fhyWEsBjC3YnrJ0X4.PSv/qHxXYGHo.'),
(6, 'hhhyyyzzz', 'Nzekwe', 'hhhh', 'ggff', 'ggg', 'Ogbaku', 'ggg', 'hhhh', '+2347064761600', 'henrykwel5@gmail.com', 'web developer', 'Ikorodu', '55', '$2y$10$uu3vJqJKY5nGuUXrgLyMdetWtJ2osAcrS.u1Wa5g4G15cPwwfizPq'),
(9, 'Henry', 'Nzekwe', 'Chimuanya', 'Igwe', 'Nzekwe Family', 'Ogbaku', 'Ernest', 'Vera', '08033449665', 'henrynekwe25@gmail.com', 'web developer', 'Ikorodu', '55', '$2y$10$51t2q8dALhkvBsRwltESfOodRvyYRJwdhqEYVIWAIwUJqWhUdPJei'),
(10, 'Henry', 'Nzekwe', 'Chimuanya', 'igwe', 'Nzekwe Family', 'Ogbaku', 'Ernest', 'Vera', '+2347060761627', 'henryzekwe25@gmail.com', 'web developer', 'Ikorodu', '55', '$2y$10$h8OSh9r..rJADw.2SxEuNeTaMCxXrZCl6iig5UVlgZKStFeB.rkoe'),
(11, 'Henry', 'Nzekwe', 'Chimuanya', 'igwe', 'Nzekwe Family', 'ijele', 'Ernest', 'Vera', '+2347064761627', 'hnzekwe25@gmail.com', 'web developer', 'Ikorodu', '23', '$2y$10$MaXWLJ350Tn9HqtRphHXie7wQKpOg1uFq4UwOLdv4L2FWke.bvgYW'),
(12, 'Henry', 'Nzekwe', 'Chimuanya', 'Indigene', 'Nzekwe Family', 'Ogbaku', 'Ernest', 'Vera', '08058624794', 'stephen@gmail.com', 'web developer', 'Ikorodu', '23', '$2y$10$6YSdmbnIbLtoGKB4Xz8HOesnaG/rI8skD1paacfwM9xyDZc3e8H8W'),
(13, 'Henry', 'Nzekwe', 'Chimuanya', 'yyy', 'Nzekwe Family', 'ijele', 'Ernest', 'Vera', '08143216869', 'stephen25@gmail.com', 'web developer', 'Ikorodu', '23', '$2y$10$7/mhTlNEi10uxaUIgIas..rtLPY7Ogeip76jURgk7s3EdfC2kF4rG'),
(14, 'Henry', 'Nzekwe', 'Chimuanya', 'rrrr', 'Nzekwe Family', 'Ogbaku', 'Ernest', 'Vera', '34706476162', 'henrkwe25@gmail.com', 'web developer', 'Ikorodu', '23', '$2y$10$nt9oaKRJuhkA4KvJm.LTH.wqpvxG0H6.c7t7kdzQqFRnwcEj5vaCe'),
(15, 'Samuel', 'Nzekwe', 'Chimuanya', 'rrr', 'Nzekwe Family', 'international', 'Ernest', 'Vera', '07014229090', 'henry225@gmail.com', 'web developer', 'Ikorodu', '23', '$2y$10$ZG6rCo4NbiGloshssF/Au.8Kjp9ALtF0IAIpoP6hlf1yQiNFmAKr6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
