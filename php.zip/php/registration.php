<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  // Validate the input
  if (empty($_POST['firstName']) || empty($_POST['lastName']) || empty($_POST['email']) || empty($_POST['phoneNumber']) || empty($_POST['password'])) {
    $em = "All fields are required";
    header("Location: ../index.php?error=$em");
    exit;
  }

  // Hash the password
  $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

  // Connect to the database
  $conn = new PDO('mysql:host=localhost;dbname=village_db', 'root', '');
  
  $sql = "SELECT * FROM users WHERE email = ? OR phoneNumber = ?";
  $stmt = $conn->prepare($sql);

  // Bind the parameters
  $stmt->bindParam(1, $_POST['email']);
  $stmt->bindParam(2, $_POST['phoneNumber']);

  // Execute the SQL statement
  $stmt->execute();

  // Check if there is a duplicate email or phoneNumber
  if ($stmt->rowCount() > 0) {
    // Display the error message
    $em = "Error: Duplicate email or phoneNumber.";
    header("Location: ../index.php?error=$em");
    exit;
  }

  // Prepare the SQL statement
  $sql = "INSERT INTO users(firstName, lastName, middleName, title, familyName, village, fatherName, motherName, phoneNumber, email, occupation, residentAddress, ageGrade, password) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
  $stmt = $conn->prepare($sql);

  // Bind the parameters
  $stmt->bindParam(1, $_POST['firstName']);
  $stmt->bindParam(2, $_POST['lastName']);
  $stmt->bindParam(3, $_POST['middleName']);
  $stmt->bindParam(4, $_POST['title']);
  $stmt->bindParam(5, $_POST['familyName']);
  $stmt->bindParam(6, $_POST['village']);
  $stmt->bindParam(7, $_POST['fatherName']);
  $stmt->bindParam(8, $_POST['motherName']);
  $stmt->bindParam(9, $_POST['phoneNumber']);
  $stmt->bindParam(10, $_POST['email']);
  $stmt->bindParam(11, $_POST['occupation']);
  $stmt->bindParam(12, $_POST['residentAddress']);
  $stmt->bindParam(13, $_POST['ageGrade']);
  $stmt->bindParam(14, $pass);

  // Execute the SQL statement
  $stmt->execute();


  // Close the connection
  $conn = null;

  // Redirect the user to the success page
  header("Location: ../home.php?success=Your account has been created successfully");
  exit;

} else {

  // Redirect the user to the index page
  header("Location: ../index.php");
  exit;

}

?>
